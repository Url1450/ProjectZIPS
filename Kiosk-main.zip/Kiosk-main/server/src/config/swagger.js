// src/config/swagger.js
import swaggerJsdoc from 'swagger-jsdoc';
import swaggerUi from 'swagger-ui-express';

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Kiosk API Documentation',
      version: '1.0.0',
      description: 'API documentation for the Kiosk Management System',
    },
    servers: [
      {
        url: 'http://localhost:5000',
        description: 'Development server',
      },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
        },
      },
      schemas: {
        // User Schema
        User: {
          type: 'object',
          properties: {
            username: {
              type: 'string',
              example: 'admin123'
            },
            password: {
              type: 'string',
              example: 'securepassword123',
              writeOnly: true
            },
            adminType: {
              type: 'string',
              enum: ['retail', 'fast-food'],
              example: 'retail'
            }
          }
        },
        // Product Schema
        Product: {
          type: 'object',
          properties: {
            name: {
              type: 'string',
              example: 'T-Shirt'
            },
            price: {
              type: 'number',
              example: 19.99,
              minimum: 1
            },
            stock: {
              type: 'number',
              example: 50,
              minimum: 0
            },
            category: {
              type: 'string',
              example: 'Clothing'
            },
            storeType: {
              type: 'string',
              enum: ['fast-food', 'retail'],
              example: 'retail'
            },
            maxQuantity: {
              type: 'number',
              nullable: true,
              example: 10
            },
            lowStockThreshold: {
              type: 'number',
              default: 5,
              example: 5
            },
            imageUrl: {
              type: 'string',
              nullable: true,
              example: 'https://example.com/image.jpg'
            }
          },
          required: ['name', 'price', 'stock', 'category', 'storeType']
        },
        // Order Item Schema
        OrderItem: {
          type: 'object',
          properties: {
            product: {
              type: 'string',
              format: 'ObjectId',
              example: '507f1f77bcf86cd799439011'
            },
            name: {
              type: 'string',
              example: 'Burger'
            },
            quantity: {
              type: 'number',
              example: 2
            },
            price: {
              type: 'number',
              example: 5.99
            }
          },
          required: ['product', 'quantity', 'price']
        },
        // Order Schema
        Order: {
          type: 'object',
          properties: {
            items: {
              type: 'array',
              items: {
                $ref: '#/components/schemas/OrderItem'
              }
            },
            totalPrice: {
              type: 'number',
              example: 25.98
            },
            storeType: {
              type: 'string',
              enum: ['retail', 'fast-food'],
              example: 'fast-food'
            },
            receiptNumber: {
              type: 'string',
              example: 'ORD-123456'
            },
            orderDate: {
              type: 'string',
              format: 'date-time',
              example: '2023-05-19T12:00:00Z'
            }
          },
          required: ['items', 'totalPrice', 'storeType', 'receiptNumber']
        }
      }
    }
  },
  apis: ['./src/routes/*.js', './src/models/*.js'], // Path to your route files
};

const specs = swaggerJsdoc(options);

export default (app) => {
  app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(specs));
};