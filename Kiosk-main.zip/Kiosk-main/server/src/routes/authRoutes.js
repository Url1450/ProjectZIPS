import express from "express";
import { login } from "../controllers/authController.js";
import { body } from "express-validator";

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Authentication
 *   description: User authentication endpoints
 */

/**
 * @swagger
 * /api/auth/admin/login:
 *   post:
 *     summary: Admin login
 *     tags: [Authentication]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - username
 *               - password
 *               - adminType
 *             properties:
 *               username:
 *                 type: string
 *               password:
 *                 type: string
 *               adminType:
 *                 type: string
 *                 enum: [retail, fast-food]
 *     responses:
 *       200:
 *         description: Login successful
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 token:
 *                   type: string
 *                 adminType:
 *                   type: string
 *       400:
 *         description: Validation error
 *       401:
 *         description: Invalid credentials
 */
router.post(
  "/admin/login",
  [
    body("username").notEmpty().withMessage("Username is required"),
    body("password").notEmpty().withMessage("Password is required"),
    body("adminType")
      .isIn(["retail", "fast-food"])
      .withMessage("Admin type must be either 'retail' or 'fast-food'"),
  ],
  login
);

export default router;