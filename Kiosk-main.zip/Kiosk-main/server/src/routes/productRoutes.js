import express from "express";
import {
  getProducts,
  getProductById,
  createProduct,
  updateProduct,
  deleteProduct,
} from "../controllers/productController.js";
import {
  createCombo,
  updateCombo,
  deleteCombo,
  getCombos,
} from "../controllers/comboController.js";
import authMiddleware from "../utils/authMiddleware.js";

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Products
 *   description: Product management endpoints
 */

/**
 * @swagger
 * /api/products:
 *   get:
 *     summary: Get all products
 *     tags: [Products]
 *     responses:
 *       200:
 *         description: List of all products
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Product'
 */

/**
 * @swagger
 * /api/products:
 *   post:
 *     summary: Create a new product (Retail Admin only)
 *     tags: [Products]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/ProductInput'
 *     responses:
 *       201:
 *         description: Product created successfully
 *       401:
 *         description: Unauthorized
 *       403:
 *         description: Forbidden (wrong admin type)
 */

// Add similar documentation for all other product routes
// Include security where needed for admin-only routes

router.get("/", getProducts);

// Retail Admin-only routes
router.post("/", authMiddleware("retail"), createProduct);
router.put("/:id", authMiddleware("retail"), updateProduct);
router.delete("/:id", authMiddleware("retail"), deleteProduct);

// Fast-Food Admin-only routes
router.post("/fast-food", authMiddleware("fast-food"), createProduct);
router.put("/fast-food/:id", authMiddleware("fast-food"), updateProduct);
router.delete("/fast-food/:id", authMiddleware("fast-food"), deleteProduct);

// Fast-Food Combo routes
router.post("/fast-food/combos", authMiddleware("fast-food"), createCombo);
router.put("/fast-food/combos/:id", authMiddleware("fast-food"), updateCombo);
router.delete("/fast-food/combos/:id", authMiddleware("fast-food"), deleteCombo);
router.get("/fast-food/combos", authMiddleware("fast-food"), getCombos);

export default router;