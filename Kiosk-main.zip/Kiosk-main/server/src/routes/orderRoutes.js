import express from "express";
import { createOrder, getOrders } from "../controllers/orderController.js";

const router = express.Router();

/**
 * @swagger
 * tags:
 *   name: Orders
 *   description: Order management endpoints
 */

/**
 * @swagger
 * /api/orders:
 *   post:
 *     summary: Create a new order
 *     tags: [Orders]
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - items
 *               - totalPrice
 *               - storeType
 *             properties:
 *               items:
 *                 type: array
 *                 items:
 *                   type: object
 *                   properties:
 *                     _id:
 *                       type: string
 *                     quantity:
 *                       type: number
 *                     price:
 *                       type: number
 *               totalPrice:
 *                 type: number
 *               storeType:
 *                 type: string
 *                 enum: [retail, fast-food]
 *     responses:
 *       201:
 *         description: Order created successfully
 *       400:
 *         description: Invalid input
 */

/**
 * @swagger
 * /api/orders:
 *   get:
 *     summary: Get all orders
 *     tags: [Orders]
 *     responses:
 *       200:
 *         description: List of all orders
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/Order'
 */
router.post("/", createOrder);
router.get("/", getOrders);

// Add this schema definition to your swagger.js options
// components: {
//   schemas: {
//     Order: {
//       type: object,
//       properties: {
//         _id: { type: string },
//         items: { type: array },
//         totalPrice: { type: number },
//         storeType: { type: string },
//         createdAt: { type: string, format: date-time }
//       }
//     }
//   }
// }

export default router;