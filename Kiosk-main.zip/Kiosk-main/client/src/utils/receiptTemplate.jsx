export const generateReceiptHTML = (order) => {
  const date = new Date(order.orderDate).toLocaleString();
  const items = order.items
    .map(
      (item) => `
    <tr>
      <td>${item?.name || "Unknown Item"}</td>
      <td>${item.quantity}x</td>
      <td>$${item.price.toFixed(2)}</td>
      <td>$${(item.quantity * item.price).toFixed(2)}</td>
    </tr>
  `
    )
    .join("");

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Order Receipt</title>
      <style>
        @page {
          size: 100mm 150mm;
          margin: 5px;
        }

        body {
          font-family: 'Courier New', monospace;
          width: 96mm; /* slightly less than 100mm to allow for padding */
          margin: 0;
          padding: 2mm;
          font-size: 11pt;
          text-align: center;
        }

        .header {
          margin-bottom: 4mm;
        }

        .store-name {
          font-size: 18pt;
          font-weight: bold;
        }

        .receipt-info {
          margin: 3mm 0;
          font-size: 11pt;
        }

        table {
          width: 100%;
          border-collapse: collapse;
          margin: 0 auto;
          text-align: center;
        }

        th, td {
          padding: 1.5mm 0;
          text-align: center;
          font-size: 11pt;
        }

        .total {
          margin-top: 4mm;
          border-top: 1px dashed #000;
          padding-top: 3mm;
          font-weight: bold;
          font-size: 12pt;
        }

        .footer {
          margin-top: 6mm;
          font-size: 10pt;
          text-align: center;
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="store-name">KIOSK ${order.storeType.toUpperCase()}</div>
        <div>Receipt #${order.receiptNumber}</div>
        <div>${date}</div>
      </div>
      
      <table>
        <thead>
          <tr>
            <th>Item</th>
            <th>Qty</th>
            <th>Price</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          ${items}
        </tbody>
      </table>
      
      <div class="total">
        <strong>Total: $${order.totalPrice.toFixed(2)}</strong>
      </div>
      
      <div class="footer">
        Thank you for shopping with us!
      </div>
    </body>
    </html>
  `;
};
